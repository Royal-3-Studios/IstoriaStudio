// FILE: src/lib/brush/backends/utils/stroke.ts
// Canonical stroke/path utilities for all backends (strict-safe; no `any`)

import type { RenderOptions, RenderPathPoint } from "@/lib/brush/engine";
import type { RNG } from "@backends/utils/random";
import { clamp, lerp } from "@backends/utils/math";
import { mapPressure, type PressureMapOpts } from "@/lib/brush/core/pressure";

/* ============================== Types ============================== */

export type TaperProfile =
  | "linear"
  | "easeIn"
  | "easeOut"
  | "easeInOut"
  | "expo"
  | "custom";

/** Optional custom LUT samples for taper curves (monotonic in [0,1]). */
export type CurveLUT = ReadonlyArray<number>;

/** Optional input-quality tuning (sandboxed in stroke.ts). */
export type InputQualityOpts = {
  /** Predictive nudge distance in CSS px; 0 = off (typical 4–12). */
  predictPx?: number;
  /** Velocity→spacing gain (−0.2..+0.4); positive loosens at speed. */
  speedToSpacing?: number;
  /** Absolute floor for step after modulation (px). */
  minStepPx?: number;
};

export interface StrokePlacementOptions {
  /** Brush diameter in CSS px. */
  baseSizePx: number;

  /** Spacing as % of diameter (e.g. 4 = 4% of diameter). */
  spacingPercent: number; // default 4

  /** Jitter as % of spacing (0..100). */
  jitterPercent?: number; // default 0.5

  /** Scatter in CSS px, normal to path, applied per stamp. */
  scatterPx?: number; // default 0

  /** Stamps per step (>=1). */
  stampsPerStep?: number; // default 1

  /** If >0, path smoothing (0..100) where higher=more smoothing. */
  streamline?: number; // default 0

  /** Angle follows path heading; 0=off, 1=fully follow. */
  angleFollowDirection?: number; // default 0

  /** Random angle jitter per stamp in degrees. */
  angleJitterDeg?: number; // default 0

  /** Clamp min tip width in px (after taper). 0 = none. */
  tipMinPx?: number; // default 0

  /** How the START tip narrows (0..1). */
  tipScaleStart?: number; // default 0.85

  /** How the END tip narrows (0..1). */
  tipScaleEnd?: number; // default 0.85

  /** Profile shapes for start and end taper. */
  taperProfileStart?: TaperProfile; // default "linear"
  taperProfileEnd?: TaperProfile; // default "linear"

  /** Optional custom curve LUTs for taper profiles (values in [0,1]). */
  taperProfileStartCurve?: CurveLUT;
  taperProfileEndCurve?: CurveLUT;

  /** Asymmetric body shaping: -1..+1 makes end thicker/thinner. */
  endBias?: number; // default 0

  /** Push thickness toward uniform marker look (0..1). */
  uniformity?: number; // default 0

  /** Random source; if omitted, Math.random() is used. */
  rng?: RNG;

  /** Pressure calibration; identity if omitted. */
  pressureMap?: PressureMapOpts;

  /** Optional input-quality tweaks; no-ops if omitted. */
  inputQuality?: InputQualityOpts;
}

export interface Stamp {
  /** CSS px position. */
  x: number;
  y: number;

  /** Degrees. Includes follow + jitter; backends may add tip angle. */
  angleDeg: number;

  /** Pressure at this point if provided upstream (0..1), else 1. */
  pressure: number;

  /** 0..1 fraction along the stroke. */
  t: number;

  /** Width scale (0..1) after taper/body shaping (pre tipMinPx clamp). */
  widthScale: number;

  /** Heading in degrees from path tangent (useful for tip orientation). */
  tangentDeg: number;
}

/** Resampled point used by backends that operate in the arc-length domain. */
export type SamplePoint = { x: number; y: number; t: number; p: number };

/** Resampled point with a tangent angle in degrees (for ribbon outlines, etc.). */
export type SampleWithAngle = SamplePoint & { tangentDeg: number };

/* ============================== Internals ============================== */

// Fully-concrete path point used internally (no optionals)
interface P {
  x: number;
  y: number;
  pressure: number;
  angleDeg: number;
  t: number; // cumulative arc fraction 0..1 (unnormalized until pathLengthAndT)
}

// Utility to assert non-undefined (strict + runtime safety)
function must<T>(v: T | undefined, where = "value"): T {
  if (v === undefined) throw new Error(`Invariant: ${where} is undefined`);
  return v;
}

function sub(a: { x: number; y: number }, b: { x: number; y: number }) {
  return { x: a.x - b.x, y: a.y - b.y };
}
function len(v: { x: number; y: number }) {
  return Math.hypot(v.x, v.y);
}
function tangentDeg(
  a: { x: number; y: number },
  b: { x: number; y: number }
): number {
  const d = sub(b, a);
  return (Math.atan2(d.y, d.x) * 180) / Math.PI;
}

/** simple one-pole smoother in *distance* domain */
function smoothPath(
  points: ReadonlyArray<RenderPathPoint>,
  alpha: number
): P[] {
  if (points.length === 0) return [];
  const out: P[] = [];
  const p0 = must(points[0], "points[0]");
  const sx0 = Number.isFinite(p0.x) ? p0.x : 0;
  const sy0 = Number.isFinite(p0.y) ? p0.y : 0;
  let sx = sx0;
  let sy = sy0;
  let sp = Number.isFinite(p0.pressure as number) ? (p0.pressure as number) : 1;
  let sa = Number.isFinite(p0.angle as number)
    ? ((p0.angle as number) * 180) / Math.PI
    : 0;
  out.push({ x: sx, y: sy, pressure: sp, angleDeg: sa, t: 0 });

  for (let i = 1; i < points.length; i++) {
    const p = must(points[i], `points[${i}]`);
    const px = Number.isFinite(p.x) ? p.x : sx;
    const py = Number.isFinite(p.y) ? p.y : sy;
    const pp = Number.isFinite(p.pressure as number)
      ? (p.pressure as number)
      : sp;
    const pa = Number.isFinite(p.angle as number)
      ? ((p.angle as number) * 180) / Math.PI
      : sa;
    sx = lerp(sx, px, alpha);
    sy = lerp(sy, py, alpha);
    sp = lerp(sp, pp, alpha);
    sa = lerp(sa, pa, alpha);
    out.push({ x: sx, y: sy, pressure: sp, angleDeg: sa, t: 0 });
  }
  return out;
}

function copyP(src: P, tOverride?: number): P {
  return {
    x: src.x,
    y: src.y,
    pressure: src.pressure,
    angleDeg: src.angleDeg,
    t: tOverride ?? src.t,
  };
}

function pathLengthAndT(points: ReadonlyArray<P>): {
  pts: P[];
  length: number;
} {
  const n = points.length;
  if (n === 0) return { pts: [], length: 0 };
  if (n === 1)
    return { pts: [copyP(must(points[0], "points[0]"), 0)], length: 0 };

  let total = 0;
  const out: P[] = new Array<P>(n);
  out[0] = copyP(must(points[0], "points[0]"), 0);
  for (let i = 1; i < n; i++) {
    const cur = must(points[i], `points[${i}]`);
    const prev = must(points[i - 1], `points[${i - 1}]`);
    const ds = len(sub(cur, prev));
    total += ds;
    out[i] = copyP(cur, total);
  }
  // normalize t to 0..1
  if (total > 0) {
    const inv = 1 / total;
    for (let i = 0; i < n; i++) {
      const o = must(out[i], `out[${i}]`);
      out[i] = copyP(o, o.t * inv);
    }
  } else {
    for (let i = 0; i < n; i++) {
      const o = must(out[i], `out[${i}]`);
      out[i] = copyP(o, 0);
    }
  }
  return { pts: out, length: total };
}

function segmentAt(
  pts: ReadonlyArray<P>,
  s: number
): { i0: number; i1: number; u: number } {
  // s in [0..1] along path t coordinate
  const n = pts.length;
  if (n < 2) return { i0: 0, i1: 0, u: 0 };
  // binary search the t array
  let lo = 0;
  let hi = n - 1;
  while (lo + 1 < hi) {
    const mid = (lo + hi) >> 1;
    const pm = must(pts[mid], `pts[${mid}]`);
    if (pm.t < s) lo = mid;
    else hi = mid;
  }
  const a = must(pts[lo], `pts[${lo}]`);
  const b = must(pts[hi], `pts[${hi}]`);
  const denom = Math.max(1e-6, b.t - a.t);
  const u = clamp((s - a.t) / denom, 0, 1);
  return { i0: lo, i1: hi, u };
}

function interp(a: P, b: P, u: number): P {
  return {
    x: lerp(a.x, b.x, u),
    y: lerp(a.y, b.y, u),
    pressure: lerp(a.pressure, b.pressure, u),
    angleDeg: lerp(a.angleDeg, b.angleDeg, u),
    t: lerp(a.t, b.t, u),
  };
}

function rand(rng?: RNG): number {
  return rng ? rng.nextFloat() : Math.random();
}

/* ---------- predictive nudge (px) & speed→spacing ---------- */

function predictPointPx(
  a: P,
  b: P,
  predictPx: number
): { x: number; y: number } {
  const px = clamp(predictPx, 0, 24); // hard clamp for stability
  if (px <= 0) return { x: b.x, y: b.y };
  const dx = b.x - a.x;
  const dy = b.y - a.y;
  const L = Math.hypot(dx, dy);
  if (L < 1e-3) return { x: b.x, y: b.y };
  const ux = dx / L;
  const uy = dy / L;
  return { x: b.x + ux * px, y: b.y + uy * px };
}

function modulatedStepPx(
  baseStepPx: number,
  localSegPx: number,
  speedToSpacing: number,
  minStepPx: number
): number {
  const nominal = Math.max(0.5, baseStepPx); // use current base step as nominal
  const ratio = clamp(localSegPx / nominal, 0, 4); // 0..4×
  const factor = clamp(1 + speedToSpacing * (ratio - 1), 0.5, 2.0);
  const step = baseStepPx * factor;
  return Math.max(minStepPx, step);
}

function pickTaperValue(
  t: number,
  profile: TaperProfile,
  custom?: CurveLUT
): number {
  const tt = clamp(t, 0, 1);
  switch (profile) {
    case "linear":
      return tt;
    case "easeIn":
      return tt * tt;
    case "easeOut":
      return 1 - (1 - tt) * (1 - tt);
    case "easeInOut":
      return tt < 0.5 ? 2 * tt * tt : 1 - Math.pow(-2 * tt + 2, 2) / 2;
    case "expo":
      return tt <= 0 ? 0 : tt >= 1 ? 1 : Math.pow(2, 10 * (tt - 1));
    case "custom":
      if (custom && custom.length >= 2) {
        const x = tt * (custom.length - 1);
        const i = Math.floor(x);
        const f = x - i;
        const a = must(custom[i], `curve[${i}]`);
        const b = must(
          custom[Math.min(custom.length - 1, i + 1)],
          `curve[${i + 1}]`
        );
        return a + (b - a) * f;
      }
      return tt;
    default:
      return tt;
  }
}

/* ============================== Public API ============================== */

/** Convenience: resolve UI spacing from RenderOptions to a *pixel* step size. */
export function spacingToStepPx(opt: RenderOptions): number {
  const spacingUi = (opt.engine.strokePath?.spacing ??
    (opt.engine.overrides?.spacing as number | undefined) ??
    6) as number;
  const baseSize = opt.baseSizePx ?? 8;
  const frac = spacingUi > 1 ? spacingUi / 100 : spacingUi;
  return Math.max(0.25, frac * baseSize);
}

/**
 * Resample a path at ~stepPx (CSS px) and carry a tangent angle in degrees.
 * Pressure is linearly interpolated; t is 0..1 over arc length.
 */
export function resampleWithAngle(
  points: ReadonlyArray<RenderPathPoint>,
  stepPx: number
): SampleWithAngle[] {
  const out: SampleWithAngle[] = [];
  if (!points || points.length < 2) return out;

  // Build concrete P points (no smoothing here)
  const Pts: P[] = points.map((p) => ({
    x: Number.isFinite(p.x) ? p.x : 0,
    y: Number.isFinite(p.y) ? p.y : 0,
    pressure: Number.isFinite(p.pressure as number)
      ? (p.pressure as number)
      : 1,
    angleDeg: Number.isFinite(p.angle as number)
      ? ((p.angle as number) * 180) / Math.PI
      : 0,
    t: 0,
  }));
  const { pts, length } = pathLengthAndT(Pts);
  if (length <= 0) return out;

  const step = Math.max(0.3, Math.min(0.75, stepPx));
  const evalAtS = (sArc: number) => {
    const s = clamp(sArc / length, 0, 1);
    const seg = segmentAt(pts, s);
    const a = must(pts[seg.i0], `pts[${seg.i0}]`);
    const b = must(pts[seg.i1], `pts[${seg.i1}]`);
    const p = interp(a, b, seg.u);
    const tan = tangentDeg(a, b);
    return { p, tan };
  };

  const first = evalAtS(0);
  out.push({
    x: first.p.x,
    y: first.p.y,
    t: 0,
    p: first.p.pressure,
    tangentDeg: first.tan,
  });

  for (let s = step; s < length; s += step) {
    const e = evalAtS(s);
    out.push({
      x: e.p.x,
      y: e.p.y,
      t: e.p.t,
      p: e.p.pressure,
      tangentDeg: e.tan,
    });
  }
  const last = evalAtS(length);
  out.push({
    x: last.p.x,
    y: last.p.y,
    t: 1,
    p: last.p.pressure,
    tangentDeg: last.tan,
  });

  return out;
}

/**
 * Build a ribbon outline from centerline samples + width function.
 * - `samples`: output of resampleWithAngle
 * - `widthAt(u)`: returns *radius in px* (not scale) at t∈[0,1]
 * Returns a Path2D suitable for `ctx.clip()` or filling.
 */
export function buildRibbonOutline(
  samples: ReadonlyArray<SampleWithAngle>,
  widthAt: (u: number) => number
): Path2D {
  const n = samples.length;
  const left: Array<{ x: number; y: number }> = [];
  const right: Array<{ x: number; y: number }> = [];

  if (n === 0) return new Path2D();

  for (let i = 0; i < n; i++) {
    const s = must(samples[i], `samples[${i}]`);
    const rad = (s.tangentDeg * Math.PI) / 180;
    const nx = -Math.sin(rad);
    const ny = Math.cos(rad);
    const w = Math.max(0.25, widthAt(s.t)); // radius in px
    left.push({ x: s.x + nx * w, y: s.y + ny * w });
    right.push({ x: s.x - nx * w, y: s.y - ny * w });
  }

  const path = new Path2D();
  // move along left side
  path.moveTo(left[0]!.x, left[0]!.y);
  for (let i = 1; i < left.length; i++) {
    const p = must(left[i], `left[${i}]`);
    path.lineTo(p.x, p.y);
  }
  // back along right side (reverse)
  for (let i = right.length - 1; i >= 0; i--) {
    const p = must(right[i], `right[${i}]`);
    path.lineTo(p.x, p.y);
  }
  path.closePath();
  return path;
}

/**
 * Turn a raw input path into evenly/variably spaced stamp placements with tapering and jitter.
 * - Input points are in **CSS px** (like RenderPathPoint).
 * - Output stamps carry angle (follow + jitter), widthScale after taper, and pressure.
 * - Optional: predictive nudge + velocity-aware spacing + pressure map (all opt-in).
 */
export function pathToStamps(
  rawPath: ReadonlyArray<RenderPathPoint>,
  opts: StrokePlacementOptions
): Stamp[] {
  if (!rawPath || rawPath.length === 0) return [];

  const spacingPct = opts.spacingPercent;
  const jitterPct = opts.jitterPercent ?? 0.5;
  const scatterPx = Math.max(0, opts.scatterPx ?? 0);
  const stampsPerStep = Math.max(1, Math.round(opts.stampsPerStep ?? 1));

  // path smoothing factor: map 0..100 -> alpha 0..1
  const streamlineAmt = clamp(opts.streamline ?? 0, 0, 100) / 100;
  const alpha = streamlineAmt <= 0 ? 1 : Math.max(0.05, 1 - streamlineAmt);

  // Smooth (if requested) into P points
  const smoothed: P[] =
    streamlineAmt > 0
      ? smoothPath(rawPath as RenderPathPoint[], alpha)
      : rawPath.map((p) => ({
          x: Number.isFinite(p.x) ? p.x : 0,
          y: Number.isFinite(p.y) ? p.y : 0,
          pressure: Number.isFinite(p.pressure as number)
            ? (p.pressure as number)
            : 1,
          angleDeg: Number.isFinite(p.angle as number)
            ? ((p.angle as number) * 180) / Math.PI
            : 0,
          t: 0,
        }));

  const { pts, length } = pathLengthAndT(smoothed);
  if (pts.length === 0) return [];

  if (length <= 0 || pts.length < 2) {
    const p0 = must(pts[0], "pts[0]");
    const t = 0.0;
    const angle =
      (opts.angleFollowDirection ?? 0) * 0 +
      (opts.angleJitterDeg ?? 0) * (rand(opts.rng) * 2 - 1);
    const widthScale = computeWidthScale(t, opts);
    return [
      {
        x: p0.x,
        y: p0.y,
        angleDeg: angle,
        pressure: mapPressure(p0.pressure, opts.pressureMap),
        t,
        widthScale,
        tangentDeg: 0,
      },
    ];
  }

  // convert spacing % to absolute distance (base step)
  const baseStep = Math.max(0.25, (spacingPct / 100) * opts.baseSizePx);

  // input quality (all optional)
  const iq = opts.inputQuality ?? {};
  const predictPx = clamp(iq.predictPx ?? 0, 0, 24);
  const kSpeed = iq.speedToSpacing ?? 0;
  const minStepPx = Math.max(0.25, iq.minStepPx ?? 0.5);

  const stamps: Stamp[] = [];
  const followAmt = clamp(opts.angleFollowDirection ?? 0, 0, 1);
  const angleJitter = Math.max(0, opts.angleJitterDeg ?? 0);

  // Walker over arc length with variable step (enables velocity-aware spacing)
  let sArc = 0;
  const endArc = length;

  // Helper to evaluate p at arc-length s (px) and optionally apply predictive nudge
  const evalAtArcWithPredict = (
    s: number
  ): { p: P; x: number; y: number; tanDeg: number } => {
    const s01 = clamp(s / length, 0, 1);
    const seg = segmentAt(pts, s01);
    const a = must(pts[seg.i0], `pts[${seg.i0}]`);
    const b = must(pts[seg.i1], `pts[${seg.i1}]`);
    const p = interp(a, b, seg.u);
    const tan = tangentDeg(a, b);

    if (predictPx > 0) {
      const nudged = predictPointPx(a, b, predictPx);
      return { p, x: nudged.x, y: nudged.y, tanDeg: tan };
    }
    return { p, x: p.x, y: p.y, tanDeg: tan };
  };

  while (sArc <= endArc + 1e-3) {
    // --- along-path jitter in *arc length px* (percent of spacing) ---
    const jitterArc = (rand(opts.rng) * 2 - 1) * (jitterPct / 100) * baseStep;
    const sArcJittered = clamp(sArc + jitterArc, 0, endArc);

    const { p, x, y, tanDeg } = evalAtArcWithPredict(sArcJittered);

    for (let k = 0; k < stampsPerStep; k++) {
      // normal for scatter (perpendicular to tangent)
      const rad = (tanDeg * Math.PI) / 180;
      const nx = -Math.sin(rad);
      const ny = Math.cos(rad);

      const scatter = scatterPx > 0 ? (rand(opts.rng) * 2 - 1) * scatterPx : 0;
      const sx = x + nx * scatter;
      const sy = y + ny * scatter;

      const followAngle = followAmt * tanDeg;
      const jitterAngle =
        angleJitter > 0 ? (rand(opts.rng) * 2 - 1) * angleJitter : 0;
      const angleDeg = followAngle + jitterAngle;

      const t = p.t; // 0..1 along the stroke
      const widthScale = computeWidthScale(t, opts);

      stamps.push({
        x: sx,
        y: sy,
        angleDeg,
        pressure: mapPressure(p.pressure, opts.pressureMap),
        t,
        widthScale,
        tangentDeg: tanDeg,
      });
    }

    // --- step advance (velocity-aware if enabled) ---
    // Use the *raw* local segment length near the unjittered sArc as a speed proxy.
    const s01 = clamp(sArc / length, 0, 1);
    const seg = segmentAt(pts, s01);
    const a = must(pts[seg.i0], `pts[${seg.i0}]`);
    const b = must(pts[seg.i1], `pts[${seg.i1}]`);
    const localSegPx = len(sub(b, a)); // px per raw-segment sample

    const stepPx =
      kSpeed !== 0
        ? modulatedStepPx(baseStep, localSegPx, kSpeed, minStepPx)
        : baseStep;
    sArc += stepPx;
  }

  return stamps;
}

/** Compute width scale 0..1 along the stroke using taper options. */
export function computeWidthScale(
  t: number,
  opts: StrokePlacementOptions
): number {
  const start = clamp(opts.tipScaleStart ?? 0.85, 0, 1);
  const end = clamp(opts.tipScaleEnd ?? 0.85, 0, 1);
  const uniformity = clamp(opts.uniformity ?? 0, 0, 1);
  const endBias = clamp(opts.endBias ?? 0, -1, 1);

  // easing for start and end
  const startProf = opts.taperProfileStart ?? "linear";
  const endProf = opts.taperProfileEnd ?? "linear";

  const sCurve = pickTaperValue(1 - t, startProf, opts.taperProfileStartCurve);
  const eCurve = pickTaperValue(t, endProf, opts.taperProfileEndCurve);

  // base scale from start/end taper
  let scale = 1.0;
  scale *= lerp(1, start, sCurve);
  scale *= lerp(1, end, eCurve);

  // endBias fattens/thins the end vs start
  if (endBias !== 0) {
    const bias = endBias > 0 ? t : 1 - t;
    scale *= lerp(1, 1.25, Math.abs(endBias) * bias);
  }

  // uniformity pushes toward flat marker look
  if (uniformity > 0) {
    scale = lerp(scale, 1.0, uniformity);
  }

  // tipMinPx clamp will be applied by backends when converting scale->pixels
  return clamp(scale, 0, 1);
}

/* ============================== Misc helpers ============================== */

/** Map UI spacing (percent or fraction) to a safe fraction of diameter. */
export function resolveSpacingFraction(
  uiSpacing?: number,
  fallbackPct = 3
): number {
  const raw = typeof uiSpacing === "number" ? uiSpacing : fallbackPct;
  const frac = raw > 1 ? raw / 100 : raw;
  return Math.max(0.02, Math.min(0.08, frac));
}

/** Resample a stroke path at ~stepPx (CSS px) keeping pressure interpolated. */
export function resamplePath(
  points: ReadonlyArray<RenderPathPoint>,
  stepPx: number
): SamplePoint[] {
  const out: SamplePoint[] = [];
  if (!points || points.length < 2) return out;

  // Build P points first (no smoothing here; caller can smooth upstream)
  const Pts: P[] = points.map((p) => ({
    x: Number.isFinite(p.x) ? p.x : 0,
    y: Number.isFinite(p.y) ? p.y : 0,
    pressure: Number.isFinite(p.pressure as number)
      ? (p.pressure as number)
      : 1,
    angleDeg: Number.isFinite(p.angle as number)
      ? ((p.angle as number) * 180) / Math.PI
      : 0,
    t: 0,
  }));
  const { pts, length } = pathLengthAndT(Pts);
  if (length <= 0) return out;

  // helper to evaluate position/pressure at target arc-length s (in px)
  function evalAtS(sArc: number) {
    const s = clamp(sArc / length, 0, 1);
    const seg = segmentAt(pts, s);
    const a = must(pts[seg.i0], `pts[${seg.i0}]`);
    const b = must(pts[seg.i1], `pts[${seg.i1}]`);
    const p = interp(a, b, seg.u);
    return p;
  }

  const first = evalAtS(0);
  out.push({ x: first.x, y: first.y, t: 0, p: first.pressure });

  const step = Math.max(0.3, Math.min(0.75, stepPx));
  for (let s = step; s < length; s += step) {
    const p = evalAtS(s);
    out.push({ x: p.x, y: p.y, t: p.t, p: p.pressure });
  }
  const last = evalAtS(length);
  out.push({ x: last.x, y: last.y, t: 1, p: last.pressure });

  return out;
}

/** Unit outward normal for segment A→B (useful for split nibs & scatter). */
export function segmentNormal(ax: number, ay: number, bx: number, by: number) {
  const dx = bx - ax;
  const dy = by - ay;
  const L = Math.hypot(dx, dy) || 1;
  return { nx: -dy / L, ny: dx / L };
}
