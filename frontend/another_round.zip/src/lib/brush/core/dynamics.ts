// src/lib/brush/core/dynamics.ts
import type { ModRoute, ModTarget, CurvePoint } from "@/lib/brush/core/types";
import { buildLUT, sampleLUT } from "../backends/utils/curves";
import { clamp, clamp01 } from "@backends/utils/math";
import type { RNG } from "../backends/utils/random";

/** Values that can drive modulation each stamp / sample. All normalized to 0..1 where applicable. */
export type ModulationContext = {
  pressure?: number; // 0..1
  speed?: number; // 0..1 (you choose mapping)
  tilt?: number; // 0..1 (0 = perpendicular, 1 = parallel)
  tiltAltitude?: number; // 0..1 (1 = stylus upright)
  tiltAzimuth?: number; // 0..1 (heading mapped to 0..1)
  random?: number; // 0..1 (if omitted and rng provided, we’ll generate)
  strokePos?: number; // 0..1 along the stroke
  stampIndex?: number; // 0..1 normalized index within the stroke
  direction?: number; // 0..1 from heading (e.g., deg/360)
  rng?: RNG; // optional RNG to generate random when random is undefined
};

/** Internal, compiled route with baked LUT and defaults. */
type CompiledRoute = {
  target: ModTarget;
  amount: number;
  mode: "add" | "mul" | "replace";
  input: keyof ModulationContext; // which ctx field
  min?: number;
  max?: number;
  lut?: Float32Array; // optional remap LUT
};

/** Compile user routes into a fast structure (with LUTs). */
export function compileRoutes(
  routes: ModRoute[] | undefined,
  lutSize = 256
): CompiledRoute[] {
  if (!routes || routes.length === 0) return [];
  const out: CompiledRoute[] = [];

  for (const r of routes) {
    if (!r || !r.input || !r.target) continue;

    const base: CompiledRoute = {
      target: r.target,
      amount: typeof r.amount === "number" ? r.amount : 1,
      mode: r.mode ?? "add",
      input: r.input as keyof ModulationContext,
      // NOTE: optional fields added below only if defined
    };

    if (typeof r.min === "number") (base as { min: number }).min = r.min;
    if (typeof r.max === "number") (base as { max: number }).max = r.max;

    if (r.curve && r.curve.length >= 2) {
      (base as { lut: Float32Array }).lut = buildLUT(
        r.curve as CurvePoint[],
        lutSize
      );
    }

    out.push(base);
  }
  return out;
}

/** Resolve the input value from context, generating randomness if desired. */
function readInput(route: CompiledRoute, ctx: ModulationContext): number {
  const k = route.input;
  if (k === "random") {
    if (typeof ctx.random === "number") return clamp01(ctx.random);
    if (ctx.rng) return ctx.rng.nextFloat();
    return Math.random();
  }
  const v = ctx[k];
  return clamp01(typeof v === "number" ? v : 0);
}

/** Apply a single compiled route to a base value, return adjusted value. */
function applyRoute(
  base: number,
  route: CompiledRoute,
  ctx: ModulationContext
): number {
  const raw = readInput(route, ctx); // 0..1
  const mapped = route.lut ? sampleLUT(route.lut, raw) : raw; // remapped 0..1
  let out = base;

  switch (route.mode) {
    case "add":
      out = base + route.amount * mapped;
      break;
    case "mul":
      // multiplicative modulation around 1: base * (1 + amount * mapped)
      out = base * (1 + route.amount * mapped);
      break;
    case "replace":
      // linear blend between base and mapped
      out = base * (1 - route.amount) + mapped * route.amount;
      break;
  }

  if (route.min !== undefined || route.max !== undefined) {
    out = clamp(out, route.min ?? -Infinity, route.max ?? Infinity);
  }
  return out;
}

/** Stateless modulator that can apply all routes to target values. */
export class Modulator {
  private byTarget: Map<ModTarget, CompiledRoute[]>;
  constructor(compiled: CompiledRoute[]) {
    this.byTarget = new Map();
    for (const r of compiled) {
      const arr = this.byTarget.get(r.target);
      if (arr) arr.push(r);
      else this.byTarget.set(r.target, [r]);
    }
  }

  /** Apply modulation to a single target value. */
  apply(target: ModTarget, base: number, ctx: ModulationContext): number {
    const routes = this.byTarget.get(target);
    if (!routes || routes.length === 0) return base;
    let v = base;
    for (const r of routes) v = applyRoute(v, r, ctx);
    return v;
  }

  /**
   * Apply modulation to a set of base values at once.
   * Only keys present in `baseByTarget` are returned.
   */
  applyAll(
    baseByTarget: Partial<Record<ModTarget, number>>,
    ctx: ModulationContext
  ): Partial<Record<ModTarget, number>> {
    const out: Partial<Record<ModTarget, number>> = {};
    for (const [target, base] of Object.entries(baseByTarget) as Array<
      [ModTarget, number]
    >) {
      out[target] = this.apply(target, base, ctx);
    }
    return out;
  }
}

/** Convenience: build a Modulator directly from user routes. */
export function buildModulator(routes?: ModRoute[], lutSize = 256): Modulator {
  return new Modulator(compileRoutes(routes, lutSize));
}
