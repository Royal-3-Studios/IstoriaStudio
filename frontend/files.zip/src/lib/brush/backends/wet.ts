// FILE: src/lib/brush/backends/wet.ts
/**
 * Wet backend — soft watercolor/ink wash with wet-edge darkening,
 * inner bloom/bleed, and pressure-driven pooling.
 *
 * Draw only in CSS space; the engine already sized the canvas and applied DPR.
 */

import type { RenderOptions } from "../engine";
import { mapPressure, type PressureMapOpts } from "@/lib/brush/core/pressure";
import type { CanvasLike, Ctx2D } from "./utils/canvas";

/* ========================================================================== *
 * Small utilities (strict-safe)
 * ========================================================================== */

const clamp01 = (v: number): number => (v < 0 ? 0 : v > 1 ? 1 : v);
const lerp = (a: number, b: number, t: number): number => a + (b - a) * t;

// strict-safe array helpers
const get = <T>(arr: readonly T[], i: number): T => arr[i]!;
const last = <T>(arr: readonly T[]): T => arr[arr.length - 1]!;
const getNum = (arr: readonly number[], i: number): number => arr[i]!;

function createCanvas(
  w: number,
  h: number
): OffscreenCanvas | HTMLCanvasElement {
  if (typeof OffscreenCanvas !== "undefined") return new OffscreenCanvas(w, h);
  const c = document.createElement("canvas");
  c.width = w;
  c.height = h;
  return c;
}

function isCtx2D(
  ctx: unknown
): ctx is CanvasRenderingContext2D | OffscreenCanvasRenderingContext2D {
  if (!ctx || typeof ctx !== "object") return false;
  const c = ctx as Partial<CanvasRenderingContext2D>;
  return (
    typeof c.clearRect === "function" &&
    typeof c.setTransform === "function" &&
    typeof c.drawImage === "function" &&
    typeof c.createRadialGradient === "function"
  );
}

function getCtx2D(
  canvas: HTMLCanvasElement | OffscreenCanvas
): CanvasRenderingContext2D | OffscreenCanvasRenderingContext2D {
  const ctx = canvas.getContext("2d");
  if (!isCtx2D(ctx)) throw new Error("2D context not available.");
  return ctx;
}

/* ========================================================================== *
 * Path helpers
 * ========================================================================== */

type InputPoint = { x: number; y: number; angle?: number; pressure?: number };
type SamplePoint = {
  x: number;
  y: number;
  angle: number;
  pressure: number;
  arcLen: number;
};

function createDefaultPreviewPath(width: number, height: number): InputPoint[] {
  const out: InputPoint[] = [];
  const x0 = Math.max(8, Math.floor(width * 0.08));
  const x1 = Math.min(width - 8, Math.floor(width * 0.92));
  const midY = Math.floor(height * 0.58);
  const amp = Math.max(8, Math.min(height * 0.33, 36));
  const steps = 72;

  for (let i = 0; i <= steps; i++) {
    const t = i / steps;
    const x = x0 + (x1 - x0) * t;
    const y = midY - amp * t + amp * 0.5 * Math.sin(6.3 * t);
    const dx = (x1 - x0) / steps;
    const dy = -amp / steps + (amp * 0.5 * 6.3 * Math.cos(6.3 * t)) / steps;
    out.push({
      x,
      y,
      angle: Math.atan2(dy, dx),
      pressure: 0.7 + 0.3 * Math.sin(3.0 * t),
    });
  }
  return out;
}

/** Resample by arc step; carry angle & pressure; arcLen monotonically increases. */
function resamplePathUniform(path: InputPoint[], step: number): SamplePoint[] {
  const n = path.length;
  if (n === 0) return [];

  const prefix: number[] = [0];
  for (let i = 1; i < n; i++) {
    const dx = get(path, i).x - get(path, i - 1).x;
    const dy = get(path, i).y - get(path, i - 1).y;
    prefix.push(getNum(prefix, i - 1) + Math.hypot(dx, dy));
  }
  const totalLen = last(prefix);
  if (totalLen <= 0) return [];

  const arcAt = (
    s: number
  ): { x: number; y: number; angle: number; pressure: number } => {
    let i = 1;
    while (i < prefix.length && getNum(prefix, i) < s) i++;
    const i1 = Math.min(prefix.length - 1, Math.max(1, i));
    const s0 = getNum(prefix, i1 - 1);
    const s1 = getNum(prefix, i1);
    const t = Math.min(1, Math.max(0, (s - s0) / Math.max(1e-6, s1 - s0)));
    const a = get(path, i1 - 1);
    const b = get(path, i1);

    const angle =
      a.angle != null && b.angle != null
        ? lerp(a.angle, b.angle, t)
        : Math.atan2(b.y - a.y, b.x - a.x);
    const pressure = lerp(a.pressure ?? 1, b.pressure ?? 1, t);
    return {
      x: lerp(a.x, b.x, t),
      y: lerp(a.y, b.y, t),
      angle,
      pressure: clamp01(pressure),
    };
  };

  const out: SamplePoint[] = [];
  for (let s = 0; s <= totalLen; s += step) {
    const p = arcAt(s);
    out.push({
      x: p.x,
      y: p.y,
      angle: p.angle,
      pressure: p.pressure,
      arcLen: s,
    });
  }
  if (last(out).arcLen < totalLen) {
    const p = arcAt(totalLen);
    out.push({
      x: p.x,
      y: p.y,
      angle: p.angle,
      pressure: p.pressure,
      arcLen: totalLen,
    });
  }
  return out;
}

/* ========================================================================== *
 * Core wet look helpers
 * ========================================================================== */

function pressureToRadiusK(p01: number): number {
  const q = clamp01(p01);
  return 0.8 + Math.pow(q, 0.8) * 0.6; // 0.8..1.4
}

function pressureToFlowK(p01: number): number {
  const q = clamp01(p01);
  return 0.55 + Math.pow(q, 1.1) * 0.75; // 0.55..1.3
}

/** Paint a soft round dab at (x,y) with radius r and opacity a. */
function paintDab(
  ctx: Ctx2D,
  x: number,
  y: number,
  r: number,
  a: number
): void {
  const grd = ctx.createRadialGradient(x, y, 0, x, y, Math.max(0.001, r));
  grd.addColorStop(0.0, `rgba(0,0,0,${(a * 0.65).toFixed(4)})`);
  grd.addColorStop(0.55, `rgba(0,0,0,${(a * 0.85).toFixed(4)})`);
  grd.addColorStop(1.0, `rgba(0,0,0,0)`);
  (ctx as unknown as { fillStyle: CanvasGradient | string }).fillStyle = grd;
  const d = r * 2;
  ctx.fillRect(x - r, y - r, d, d);
}

/* ========================================================================== *
 * Input mapping helpers (pressure curve + predictive nudge)
 * ========================================================================== */

function toPressureMapFromInput(
  opt: RenderOptions
): PressureMapOpts | undefined {
  const input = opt.input;
  if (!input) return undefined;

  const gamma =
    input.pressure.curve?.type === "gamma"
      ? input.pressure.curve.gamma
      : undefined;
  const deadZone =
    typeof input.pressure.clamp?.min === "number"
      ? Math.max(0, Math.min(0.5, input.pressure.clamp.min))
      : undefined;

  // exactOptionalPropertyTypes-safe: only include keys when defined
  const out: Partial<PressureMapOpts> = {};
  if (gamma !== undefined) out.gamma = gamma;
  if (deadZone !== undefined) out.deadZone = deadZone;

  return Object.keys(out).length ? (out as PressureMapOpts) : undefined;
}

/* ========================================================================== *
 * Main renderer (draw in CSS space; DPR handled by engine)
 * ========================================================================== */

export async function drawWetToCanvas(
  canvas: CanvasLike,
  opt: RenderOptions
): Promise<void> {
  const ctx = canvas.getContext("2d", { alpha: true }) as Ctx2D | null;
  if (!ctx) throw new Error("2D context not available.");

  // Engine has already set DPR transform on this context; draw in CSS space.
  const viewW = Math.max(1, Math.floor(opt.width));
  const viewH = Math.max(1, Math.floor(opt.height));
  ctx.clearRect(0, 0, viewW, viewH);
  ctx.imageSmoothingEnabled = true;
  (
    ctx as unknown as { imageSmoothingQuality?: ImageSmoothingQuality }
  ).imageSmoothingQuality = "high";

  // Inputs
  const num = (v: unknown, d: number): number =>
    typeof v === "number" ? v : d;
  const flow01 = clamp01(
    num(opt.overrides?.flow ?? opt.engine?.overrides?.flow, 100) / 100
  );
  const opacity01 = clamp01(
    num(opt.overrides?.opacity ?? opt.engine?.overrides?.opacity, 100) / 100
  );
  const baseRadius = Math.max(0.5, (opt.baseSizePx ?? 8) * 0.5);
  const strokeColor = opt.color ?? "#000000";

  // Respect rendering mode & overrides for wet edges
  const wetEdgesEnabled =
    (opt.overrides?.wetEdges ??
      opt.engine?.overrides?.wetEdges ??
      opt.engine?.rendering?.wetEdges ??
      (opt.engine?.rendering?.mode as string | undefined) === "wet") === true;

  // Path
  const inputPath: InputPoint[] =
    opt.path && opt.path.length > 1
      ? (opt.path as InputPoint[])
      : createDefaultPreviewPath(viewW, viewH);

  // Resample (uniform arc length)
  const arcStep = Math.max(0.42, baseRadius * 0.18);
  let samples: SamplePoint[] = resamplePathUniform(inputPath, arcStep);
  if (samples.length === 0) return;

  // Predictive nudge; fade toward tips.
  const predictPx = clamp01(num(opt.input?.quality?.predictPx, 0) / 24) * 24;
  if (predictPx > 0 && samples.length >= 2) {
    const totalLen = last(samples).arcLen || 1;
    samples = samples.map((s, i) => {
      const prev = i > 0 ? get(samples, i - 1) : s;
      const next = i < samples.length - 1 ? get(samples, i + 1) : s;
      const ang = Math.atan2(next.y - prev.y, next.x - prev.x);
      const u = s.arcLen / totalLen;
      const fade = 1 - 4 * Math.pow(u - 0.5, 2); // bell 0..1..0
      const k = predictPx * Math.max(0, fade);
      return {
        x: s.x + Math.cos(ang) * k,
        y: s.y + Math.sin(ang) * k,
        angle: s.angle,
        pressure: s.pressure,
        arcLen: s.arcLen,
      };
    });
  }

  // Pressure mapping (gamma/deadZone) from input curve/clamp
  const pmap = toPressureMapFromInput(opt);
  if (pmap) {
    for (let i = 0; i < samples.length; i++) {
      const s = get(samples, i);
      s.pressure = clamp01(mapPressure(s.pressure, pmap));
    }
  }

  /* A) Accumulate mask (wet pigment deposit, grayscale) */
  const mask = createCanvas(viewW, viewH);
  const mx = getCtx2D(mask);
  mx.clearRect(0, 0, viewW, viewH);
  mx.globalCompositeOperation = "source-over";
  (mx as unknown as { filter?: string }).filter = "none";

  for (let i = 0; i < samples.length; i++) {
    const s = get(samples, i);
    const r = baseRadius * pressureToRadiusK(s.pressure);
    const a = opacity01 * flow01 * 0.22 * pressureToFlowK(s.pressure);
    paintDab(mx as unknown as Ctx2D, s.x, s.y, Math.max(0.5, r), a);
  }

  /* B) Diffusion (soft bleed) */
  (mx as unknown as { filter?: string }).filter = "blur(0.9px)";
  mx.drawImage(mask as CanvasImageSource, 0, 0);
  (mx as unknown as { filter?: string }).filter = "none";

  /* C) Wet edge emphasis */
  if (wetEdgesEnabled) {
    const edge = createCanvas(viewW, viewH);
    const ex = getCtx2D(edge);
    ex.clearRect(0, 0, viewW, viewH);
    ex.drawImage(mask as CanvasImageSource, 0, 0);

    ex.globalCompositeOperation = "source-over";
    (ex as unknown as { filter?: string }).filter = "blur(1.6px)";
    ex.drawImage(edge as CanvasImageSource, 0, 0);
    (ex as unknown as { filter?: string }).filter = "none";

    ex.globalCompositeOperation = "destination-out";
    (ex as unknown as { filter?: string }).filter = "blur(0.9px)";
    ex.drawImage(mask as CanvasImageSource, 0, 0);
    (ex as unknown as { filter?: string }).filter = "none";
    ex.globalCompositeOperation = "source-over";

    mx.globalCompositeOperation = "multiply";
    mx.globalAlpha = opacity01 * clamp01(flow01 * 0.9);
    mx.drawImage(edge as CanvasImageSource, 0, 0);
    mx.globalAlpha = 1;
    mx.globalCompositeOperation = "source-over";
  }

  /* D) Inner bloom (watery lift) */
  {
    const bloom = createCanvas(viewW, viewH);
    const bx = getCtx2D(bloom);
    bx.clearRect(0, 0, viewW, viewH);
    bx.drawImage(mask as CanvasImageSource, 0, 0);

    bx.globalCompositeOperation = "source-over";
    (bx as unknown as { filter?: string }).filter = "blur(1.8px)";
    bx.drawImage(bloom as CanvasImageSource, 0, 0);
    (bx as unknown as { filter?: string }).filter = "none";

    bx.globalCompositeOperation = "destination-in";
    (bx as unknown as { filter?: string }).filter = "blur(0.6px)";
    bx.drawImage(mask as CanvasImageSource, 0, 0);
    (bx as unknown as { filter?: string }).filter = "none";
    bx.globalCompositeOperation = "source-over";

    mx.globalCompositeOperation = "screen";
    mx.globalAlpha = opacity01 * 0.22;
    mx.drawImage(bloom as CanvasImageSource, 0, 0);
    mx.globalAlpha = 1;
    mx.globalCompositeOperation = "source-over";
  }

  /* E) Core reinforcement */
  {
    const firstS = get(samples, 0);
    const lastS = last(samples);
    mx.globalCompositeOperation = "multiply";
    const core = (
      mx as unknown as {
        createLinearGradient: (
          x0: number,
          y0: number,
          x1: number,
          y1: number
        ) => CanvasGradient;
      }
    ).createLinearGradient(firstS.x, firstS.y, lastS.x, lastS.y);
    core.addColorStop(0.0, "rgba(0,0,0,0.15)");
    core.addColorStop(0.5, "rgba(0,0,0,0.30)");
    core.addColorStop(1.0, "rgba(0,0,0,0.15)");
    (mx as unknown as { fillStyle: CanvasGradient | string }).fillStyle = core;
    mx.fillRect(0, 0, viewW, viewH);
    mx.globalCompositeOperation = "source-over";
  }

  /* F) Tint with stroke color, clip by mask, draw to destination */
  const tinted = createCanvas(viewW, viewH);
  const tx = getCtx2D(tinted);
  tx.clearRect(0, 0, viewW, viewH);

  // Fill solid color
  (tx as unknown as { fillStyle: string }).fillStyle = strokeColor;
  tx.fillRect(0, 0, viewW, viewH);

  // Clip by wet mask
  tx.globalCompositeOperation = "destination-in";
  tx.drawImage(mask as CanvasImageSource, 0, 0);
  tx.globalCompositeOperation = "source-over";

  // Composite to destination (engine-level final blend/opacity still applies)
  ctx.globalCompositeOperation = "source-over";
  ctx.drawImage(tinted as CanvasImageSource, 0, 0);
}

export default drawWetToCanvas;
