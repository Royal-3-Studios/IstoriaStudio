// FILE: src/lib/brush/engine.types.ts

import type { BrushInputConfig } from "@/data/brushPresets";

/* ============================== Enums/Strings ============================== */

export type BrushBackend =
  | "auto"
  | "ribbon"
  | "stamping"
  | "spray"
  | "wet"
  | "smudge"
  | "particle"
  | "pattern"
  | "impasto";

export type RenderingMode = "blended" | "glazed" | "marker" | "spray" | "wet";

/* ================================= Shapes ================================= */

export type EngineShape = {
  type?:
    | "oval"
    | "round"
    | "nib"
    | "image"
    | "chisel"
    | "square"
    | "spray"
    | "charcoal";
  angle?: number; // deg
  softness?: number; // 0..100
  roundness?: number; // 0..100
  sizeScale?: number; // scalar
};

export type EngineStrokePath = {
  /** % of diameter per step for stamping/spray; typical 4..20. */
  spacing?: number;
  /** Portion of spacing used to jitter along the path (0..1). */
  jitter?: number;
  /** Scatter orthogonal to path (px). */
  scatter?: number;
  /** Path smoothing / streamline (0..100). */
  streamline?: number;
  /** Stamps per step (multi-nib / split). */
  count?: number;
};

export type EngineGrain = {
  kind?: "none" | "paper" | "canvas" | "noise";
  depth?: number; // 0..100
  scale?: number; // 0.5..3
  rotate?: number; // deg
  motion?: "paperLocked" | "tipLocked" | "smudgeLocked";
};

export type EngineRendering = {
  mode?: RenderingMode;
  wetEdges?: boolean;
  flow?: number; // 0..100
  /** Global blend used when compositing the offscreen stroke layer. */
  blendMode?: CanvasRenderingContext2D["globalCompositeOperation"];
};

/* ============================== Overrides ================================= */

export type RenderOverrides = {
  /* Placement & distribution */
  spacing?: number;
  jitter?: number;
  scatter?: number;
  count?: number;

  /* Tip / orientation */
  angle?: number;
  softness?: number;
  sizeJitter?: number;
  angleJitter?: number;
  angleFollowDirection?: number;

  /* Dynamics */
  flow?: number;
  opacity?: number; // 0..100
  buildup?: boolean;
  coreStrength?: number;

  /* Grain */
  grainKind?: "none" | "paper" | "canvas" | "noise";
  grainScale?: number;
  grainDepth?: number;
  grainRotate?: number;
  grainMotion?: "paperLocked" | "tipLocked" | "smudgeLocked";

  /* Wet hint */
  wetEdges?: boolean;

  /* Smudge-specific */
  smudgeStrength?: number; // 0..2 (movement factor)
  smudgeAlpha?: number; // 0..2 (alpha multiplier)
  smudgeBlur?: number; // px
  smudgeSpacing?: number; // % or fraction

  /* Pencil / rim (used by some backends) */
  centerlinePencil?: boolean;
  rimMode?: "auto" | "on" | "off";
  rimStrength?: number;
  bgIsLight?: boolean;

  /* Paper tooth */
  toothBody?: number;
  toothFlank?: number;
  toothScale?: number;

  /* Stroke geometry (taper/body) */
  tipScaleStart?: number;
  tipScaleEnd?: number;
  tipMinPx?: number;
  bellyGain?: number;
  endBias?: number;
  uniformity?: number;
  tipRoundness?: number;
  thicknessCurve?: number;

  taperProfileStart?:
    | "linear"
    | "easeIn"
    | "easeOut"
    | "easeInOut"
    | "expo"
    | "custom";
  taperProfileEnd?:
    | "linear"
    | "easeIn"
    | "easeOut"
    | "easeInOut"
    | "expo"
    | "custom";
  taperProfileStartCurve?: number[];
  taperProfileEndCurve?: number[];

  /* Split nibs */
  splitCount?: number;
  splitSpacing?: number;
  splitSpacingJitter?: number;
  splitCurvature?: number;
  splitAsymmetry?: number;
  splitScatter?: number;
  splitAngle?: number;
  pressureToSplitSpacing?: number;
  tiltToSplitFan?: number;

  /* Speed dynamics */
  speedToWidth?: number;
  speedToFlow?: number;
  speedSmoothingMs?: number;

  /* Tilt routing */
  tiltToSize?: number;
  tiltToFan?: number;
  tiltToGrainScale?: number;
  tiltToEdgeNoise?: number;

  /* Edge noise / dry fringe */
  edgeNoiseStrength?: number;
  edgeNoiseScale?: number;
  dryThreshold?: number;

  /* Extra knobs (future-proof; optional in backends) */
  innerGrainAlpha?: number; // 0..1
  edgeCarveAlpha?: number; // 0..1

  /* ------- Input quality knobs (consumed by stroke samplers) ------- */
  /** Predictive forward nudge in CSS px (0 disables). */
  predictPx?: number;
  /**
   * Velocity → spacing gain (−0.3..+0.5). Positive loosens spacing at speed,
   * negative tightens. Backends pass to stroke.ts stepping modulation.
   */
  speedToSpacing?: number;
  /** Minimum absolute step in px after modulation. */
  minStepPx?: number;
};

export type EngineConfig = {
  /** Bump when you change the config/override surface in breaking ways. */
  version?: number; // default: 1
  backend?: BrushBackend;
  shape?: EngineShape;
  strokePath?: EngineStrokePath;
  grain?: EngineGrain;
  rendering?: EngineRendering;
  overrides?: Partial<RenderOverrides>;
  /** Reserved for curves/envelopes etc. */
  modulations?: unknown;
};

/* ============================== Render types ============================== */

export type RenderPathPoint = {
  x: number;
  y: number;
  angle?: number;
  /** Full name; kept for clarity and external integrations */
  pressure?: number;
  /** Shorthand used by some samplers/utilities */
  p?: number;
  /** Optional timestamp (ms since epoch or perf.now), if you stream points */
  t?: number;
  tilt?: number;
};

export type RenderOptions = {
  engine: EngineConfig;
  /** Nominal diameter (CSS px) before shape.sizeScale. */
  baseSizePx: number;

  color?: string; // hex "#000000"
  width: number; // CSS px
  height: number; // CSS px
  seed?: number;

  /** Preferred */
  pixelRatio?: number;
  /** Legacy alias (deprecated) — normalize to pixelRatio if present */
  dpr?: number;

  path?: Array<RenderPathPoint>;

  colorJitter?: { h?: number; s?: number; l?: number; perStamp?: boolean };
  /** Per-stroke runtime overrides (merged over engine.overrides). */
  overrides?: Partial<RenderOverrides>;

  /** Optional per-preset input metadata (pressure curve, smoothing, sampling) */
  input?: BrushInputConfig;
};

export type NormalizedRenderOptions = RenderOptions & {
  engine: Required<EngineConfig>;
  pixelRatio: number;
  width: number;
  height: number;
  baseSizePx: number;
  color: string;
  input: BrushInputConfig;
};
